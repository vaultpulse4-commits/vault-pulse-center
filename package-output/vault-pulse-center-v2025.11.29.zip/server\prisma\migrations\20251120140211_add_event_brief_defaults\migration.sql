-- AlterTable
ALTER TABLE "EventBrief" ALTER COLUMN "genre" SET DEFAULT '',
ALTER COLUMN "setTimes" SET DEFAULT '',
ALTER COLUMN "monitorNeeds" SET DEFAULT '',
ALTER COLUMN "ljCueNotes" SET DEFAULT '',
ALTER COLUMN "vjContentChecklist" SET DEFAULT '',
ALTER COLUMN "timecodeRouting" SET DEFAULT '',
ALTER COLUMN "sfxNotes" SET DEFAULT '';
